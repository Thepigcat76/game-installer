from abc import ABC, abstractmethod
from typing import Self

class RegistryObject(ABC):
    @abstractmethod
    def getName(self):
        pass

    @abstractmethod
    def getObject(name: str) -> Self:
        pass
