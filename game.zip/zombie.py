from goodmath import Vec2i, Vec2f, lerp, random
from living import LivingBeing
from player import Player
import pygame
from utils import loadTexture

texture = loadTexture("monster")

class Zombie(LivingBeing):
    target: Vec2f = None
    player: Player

    def setPlayer(self, player: Player):
        self.player = player

    def tick(self, gameTime: int):
        if self.target != None and not self.player.pos.withinDistance(self.target, 10):
            self.target = Vec2f(self.player.pos.x, self.player.pos.y)

        if self.target != None:
            diff: Vec2f = Vec2f((self.target.x - self.pos.x) / 1000, (self.target.y - self.pos.y) / 1000)
            self.setDeltaMovement(diff)
        else:
            self.target = self.player.pos

        if self.pos.withinDistance(self.player.pos, 10):
            if gameTime % 30 == 0:
                self.player.damage(1)

    def move(self, dt: int):
        self.pos.x += self.deltaMov.x * dt
        self.pos.y += self.deltaMov.y * dt

    def getTexture(self):
        return texture