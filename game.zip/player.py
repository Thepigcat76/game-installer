import pygame
from goodmath import Vec2f, Vec2i, TilePos, ChunkPos, posToTilePos, posToChunkPos
from living import LivingBeing
from world import World, COLS, ROWS
from utils import loadTexture
from item import ItemInstance
import items

SCALE = 64

texture = pygame.transform.scale(loadTexture("axel"), (SCALE, SCALE))

class Player(LivingBeing):
    rect: pygame.Rect
    health: int
    display: pygame.Surface
    tilePos: TilePos
    chunkPos: ChunkPos
    selected_item: ItemInstance
    
    def __init__(self, display: pygame.Surface, world: World, pos: Vec2f) -> None:
        super().__init__(world, pos)
        self.health = 10
        self.display = display
        self.rect = pygame.rect.Rect(0, 0, SCALE, SCALE)
        self.tilePos = posToTilePos(self.pos)
        self.chunkPos = posToChunkPos(self.tilePos)
        self.world.renderOffset = Vec2i(int(self.pos.x), int(self.pos.y))
        self.selected_item = ItemInstance(items.EMPTY, 0)

    def getTexture(self):
        return texture
    
    def damage(self, amount: int):
        self.health -= amount

    def heal(self, amount: int):
        self.health += amount

    def render(self):
        self.display.blit(self.getTexture(), (32 * ROWS / 20, 32 * COLS / 20))

    def setPos(self, x, y):
        super().setPos(x, y)
        oldChunkPos = self.chunkPos
        self.tilePos = posToTilePos(self.pos)
        self.chunkPos = posToChunkPos(self.tilePos)
        if oldChunkPos != self.chunkPos:
            self.world.genChunk(self.chunkPos)
        self.world.renderOffset = Vec2i(int(self.pos.x), int(self.pos.y))
