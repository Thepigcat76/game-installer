import pygame
import os
import consts

CHUNK_SIZE: int = 8

def texturePath(path) -> str:
    return consts.DIR + "assets/"+path+".png"

def loadTexture(path: str) -> pygame.Surface:
    return pygame.image.load(texturePath(path))