from abc import ABC, abstractmethod

class Serializable(ABC):
    @abstractmethod
    def deserialize(self, data: dict[str, str]):
        pass

    @abstractmethod
    def serialize(self) -> dict[str, str]:
        pass
