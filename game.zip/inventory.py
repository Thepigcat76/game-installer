import pygame
from goodmath import Vec2i
from player import Player
from container import Container
from utils import loadTexture
from item import ItemInstance

SCALE = 66
TEXTURE = pygame.transform.scale(loadTexture("slot"), (SCALE, SCALE))
SLOTS = 9

class Inventory:
    player: Player
    contents: Container

    def __init__(self, player: Player):
        self.player = player
        self.contents = Container()

    def render(self, screen: pygame.Surface, pos: Vec2i):
        for i in range(SLOTS):
            screen.blit(TEXTURE, (pos.x + i * SCALE, pos.y))
            if i < len(self.contents.items):
                item = self.contents.items[i].item
                item.render(screen, Vec2i(pos.x + i * item.texture.get_width() * 1.6 + 10, pos.y + 10))

    def hovered(self, mouse_pos: Vec2i, pos: Vec2i):
        return mouse_pos.x > pos.x and mouse_pos.x < pos.x + SLOTS * SCALE and mouse_pos.y > pos.y and mouse_pos.y < pos.y + SCALE

    def mouse_clicked(self, mouse_pos: Vec2i, pos: Vec2i):
        index = int((mouse_pos.x - pos.x) / SCALE)
        if index < len(self.contents.items):
            item: ItemInstance = self.contents.items[index]
            print(item.item.getName())
            if not item.item.isEmpty():
                self.player.selected_item = item