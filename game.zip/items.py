from item import ItemType, ItemInstance

EMPTY: ItemType = ItemType("empty", empty=True)
AXEL: ItemType = ItemType("axel")
PICKAXE: ItemType = ItemType("pickaxe")