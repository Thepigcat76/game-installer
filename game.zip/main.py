import pygame
from living import LivingBeing
from zombie import Zombie
from player import Player
from goodmath import Vec2f, Vec2i, ChunkPos, random, posToChunkPos
from world import COLS, ROWS, World
import tiles
import items
import json
from item import ItemType, ItemInstance
import os
import save
from container import Container
from inventory import Inventory
from utils import loadTexture, CHUNK_SIZE
import consts

pygame.init()

WORLD_SAVE_FILE = consts.DIR + "save/world-save.json"
INVENTORY_SAVE_FILE = consts.DIR + "save/inventory-save.json"

screen: pygame.Surface = pygame.display.set_mode((32 * ROWS / 10, 32 * COLS / 10))
pygame.display.set_caption("yet-to-be-named-game")
pygame.display.set_icon(loadTexture('floppa'))

monsters: list[LivingBeing] = []

velocity: float = 0.2

clock = pygame.time.Clock()

def main():
    gameTime: int = 0

    world: World = World()
    player: Player = Player(screen, world, Vec2f(100, 100))

    world.createTile(tiles.STONE)
    world.createTile(tiles.DIRT)
    
    # Textures
    axel = loadTexture("axel")
    herz = loadTexture("herz")
    axel_zuhause = loadTexture("landscape")
    my_font = pygame.font.SysFont('Comic Sans MS', 30)

    container = Container([])
    inventory = Inventory(player)
    inventory.contents = container
    inventory_pos = Vec2i(12, 45)

    load_data_from_json(WORLD_SAVE_FILE, world)
    load_data_from_json(INVENTORY_SAVE_FILE, inventory.contents)

    while True:
        deltaTime = clock.tick(60)
        pos = pygame.mouse.get_pos()
        mouse_pos = Vec2i(pos[0], pos[1])
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                world_data = world.serialize()
                save_data_to_json(WORLD_SAVE_FILE, world_data)
                inventory_data = container.serialize()
                save_data_to_json(INVENTORY_SAVE_FILE, inventory_data)
                pygame.quit()
                exit(0)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_0:
                    zombie = Zombie(world, Vec2f(random(0, 500), random(0, 500)))
                    zombie.setPlayer(player)
                    monsters.append(zombie)
                if event.key == pygame.K_1:
                    zombie = monsters[0]
                    if (isinstance(zombie, Zombie)):
                        zombie.target = Vec2f(player.pos.x, player.pos.y)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed()[0]:
                    if (inventory.hovered(mouse_pos, inventory_pos)):
                        inventory.mouse_clicked(mouse_pos, inventory_pos)
                    else:
                        chunkPos = player.chunkPos
                        x = int(mouse_pos.x - world.renderOffset.x) / 32 - chunkPos.x
                        y = int(mouse_pos.y - world.renderOffset.y) / 32 - chunkPos.y
                        print(f"x: {x}, y: {y}")
                        index: int = int(y) * CHUNK_SIZE + int(x)
                        print(f"Index: {index}, Length: {len(world.chunks[chunkPos].tiles)}")
                        world.chunks[chunkPos].tiles[index]
                elif pygame.mouse.get_pressed()[2]:
                    print('Right mouse button pressed!')

        keys = pygame.key.get_pressed()

        if keys[pygame.K_RIGHT]:
            player.setPos(player.pos.x - velocity * deltaTime, player.pos.y)
        if keys[pygame.K_LEFT]:
            player.setPos(player.pos.x + velocity * deltaTime, player.pos.y)
        if keys[pygame.K_UP]:
            player.setPos(player.pos.x, player.pos.y + velocity * deltaTime)
        if keys[pygame.K_DOWN]:
            player.setPos(player.pos.x, player.pos.y - velocity * deltaTime)

        herz = pygame.transform.scale(herz, (60, 40))
        axel_zuhause = pygame.transform.scale(axel_zuhause, (screen.get_width(),  screen.get_height()))

        screen.fill((0, 180, 210))
        world.surface.fill((0, 0, 0))
        world.render()

        for zombie in monsters:
            zombie.render()

        for zombie in monsters:
            zombie.tick(gameTime)
            zombie.move(deltaTime)

        text = my_font.render("AXEL", False, (0, 0, 0))
        world.surface.blit(text, (player.pos.x + 30, player.pos.y - 60))

        screen.blit(world.surface, (0, 0))

        for i in range(0, player.health):
            screen.blit(herz, (i * 50, 0))

        text = my_font.render(f"{player.health}x", False, (0, 0, 0))
        screen.blit(text, (9 * 50, 0))

        player.render()

        inventory.render(screen, inventory_pos)

        player.selected_item.item.render(screen, Vec2i(mouse_pos.x, mouse_pos.y))

        pygame.display.flip()
        gameTime += 1

def load_data_from_json(path: str, obj: save.Serializable):
    if os.path.isfile(path):
        with open(path, "r") as file:
            data = json.load(file)
            if path == INVENTORY_SAVE_FILE:
                print(f"Data: {data}")
            obj.deserialize(data)

def save_data_to_json(filename: str, data):
    with open(filename, "w") as file:
        json.dump(data, file)

if __name__ == "__main__":
    main()