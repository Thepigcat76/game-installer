from world import Tile

STONE: Tile = Tile("stone", (32, 32))
DIRT: Tile = Tile("dirt", (32, 32))