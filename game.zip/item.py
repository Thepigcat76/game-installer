from registry import RegistryObject
import pygame
import utils
import goodmath
import save
from typing import Self

class ItemType(RegistryObject):
    name: str
    texture: pygame.Surface
    empty: bool

    def __init__(self, name: str, dimensions: tuple[int, int] = (40, 40), empty: bool = False):
        self.name = name
        self.texture = pygame.transform.scale(utils.loadTexture(name), dimensions)
        ITEMS[name] = self
        self.empty = empty

    def isEmpty(self):
        return self.empty

    def getName(self):
        return self.name
    
    def getObject(name: str):
        return ITEMS[name]

    def render(self, surface: pygame.Surface, pos: goodmath.Vec2i):
        if not self.empty:
            surface.blit(self.texture, (pos.x, pos.y))

    def __str__(self) -> str:
        return f"ItemType{{name={self.name}}}"

ITEMS: dict[str, ItemType] = {}

class ItemInstance(save.Serializable):
    item: ItemType
    count: int

    def __init__(self, item: ItemType, count: int = 1):
        self.item = item
        self.count = count

    def copy(self) -> Self:
        return Self(self.item, self.count)

    def deserialize(self, data):
        print(ITEMS)
        print(type(data))
        print(f"Data: {data}")
        item = data["item"]
        print(str(item))
        self.item = ITEMS[item]
        self.count = data["count"]

    def serialize(self):
        data = {}
        data["item"] = self.item.getName()
        data["count"] = self.count
        return data
