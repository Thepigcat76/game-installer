import save
from item import ItemInstance

class Container(save.Serializable):
    items: list[ItemInstance]

    def __init__(self, items: list[ItemInstance] = []):
        self.items = items

    def deserialize(self, data):
        print(f"Container Data: {data}")
        for i in range(data["size"]):
            item = data["items"][i]
            print(f"Item data: {item}")
            instance = ItemInstance(None, 0)
            instance.deserialize(item)
            self.items.append(instance)
        return super().deserialize(data)
    
    def serialize(self):
        data = {}
        items = []
        for item in self.items:
            items.append(item.serialize())
        data["items"] = items
        data["size"] = len(items)
        return data
