import pygame
from goodmath import Vec2f
import abc
from world import World

class LivingBeing(abc.ABC):
    world: World
    pos: Vec2f
    deltaMov: Vec2f

    def __init__(self, world: World, pos: Vec2f) -> None:
        self.world = world
        self.pos = pos
        self.deltaMov = Vec2f(0, 0)

    def render(self):
        self.world.surface.blit(self.getTexture(), (self.pos.x, self.pos.y))

    def setDeltaMovement(self, movement: Vec2f):
        self.deltaMov = movement

    def tick(self, gameTime: int):
        pass

    def move(self, dt: int):
        pass

    def setPos(self, pos: Vec2f):
        self.setPos(pos.x, pos.y)

    def setPos(self, x: float, y: float):
        self.pos.x = x
        self.pos.y = y

    @abc.abstractmethod
    def getTexture(self):
        ...