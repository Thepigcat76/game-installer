import pygame
import utils
from goodmath import Vec2i, random, ChunkPos
from utils import CHUNK_SIZE
from save import Serializable

class Tile:
    surface: pygame.Surface
    texture: pygame.Surface
    name: str

    def __init__(self, path: str, dimensions: tuple[int, int]) -> None:
        self.name = path
        self.texture = pygame.transform.scale(utils.loadTexture(path), dimensions)

    def render(self, pos: Vec2i):
        self.surface.blit(self.texture, (pos.x, pos.y))

TILES: dict[str, Tile] = {}
COLS: int = 200
ROWS: int = 200

CHUNKS: int = 0

class Chunk(Serializable):
    id: int
    tiles: list[Tile]
    chunkPos: ChunkPos

    def __init__(self, chunkPos: ChunkPos) -> None:
        self.id = CHUNKS
        self.tiles = []
        self.chunkPos = chunkPos
        for _ in range(CHUNK_SIZE * CHUNK_SIZE):
            self.tiles.append(list(TILES.values())[random(0, len(TILES)-1)])

    def render(self, renderOffset: Vec2i):
        initialSize = CHUNK_SIZE * 32 / 2
        for row in range(CHUNK_SIZE):
            for tileIndex in range(CHUNK_SIZE):
                pos = Vec2i((renderOffset.x + self.chunkPos.x * CHUNK_SIZE * 32) + initialSize + tileIndex * 32, (renderOffset.y + self.chunkPos.y * CHUNK_SIZE * 32) + initialSize + row * 32)
                self.tiles[row * tileIndex + tileIndex].render(pos)

    def serialize(self) -> dict:
        data = {}
        data["id"] = str(self.id)
        data["chunkPos"] = self.chunkPos.serialize()
        tiles: list[str] = []
        for tile in self.tiles:
            tiles.append(tile.name)
        data["tiles"] = tiles
        return data

    def deserialize(self, data: dict):
        self.id = int(data["id"])
        self.chunkPos.deserialize(data["chunkPos"])
        self.tiles = []
        for tile in data["tiles"]:
            self.tiles.append(TILES.get(tile))
 
class World(Serializable):
    gameTime: int
    screen: pygame.Surface
    surface: pygame.Surface
    chunks: dict[ChunkPos, Chunk]
    renderOffset: Vec2i = Vec2i(0, 0)

    def __init__(self) -> None:
        self.gameTime = 0
        self.surface = pygame.Surface((4000, 4000), pygame.SRCALPHA)
        self.chunks = {}

    def createTile(self, tile: Tile):
        tile.surface = self.surface
        TILES[tile.name] = tile

    def genChunk(self, chunkPos: ChunkPos):
        if not chunkPos in self.chunks:
            self.chunks[chunkPos] = Chunk(chunkPos)

    def render(self):
        for chunk in self.chunks.values():
            chunk.render(self.renderOffset)

    def deserialize(self, data: dict[str, str]):
        for pos, chunk in data["chunks"].items():
            chunkPos = ChunkPos(0, 0)
            temp_chunk = Chunk(chunkPos)
            chunkPos.deserialize(pos)
            temp_chunk.deserialize(chunk)
            self.chunks[chunkPos] = temp_chunk

    def serialize(self) -> dict[str, str]:
        chunks: dict[str, dict] = {}
        for pos, chunk in self.chunks.items():
            chunks[pos.serialize()] = chunk.serialize()
        return {
            "chunks": chunks
        }
