from random import randint
from utils import CHUNK_SIZE
import math

class Vec2i:
    x: int
    y: int

    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y
    
    def __str__(self) -> str:
        return f"Vec2i{{x: {self.x}, y: {self.y}}}"
    
    def __eq__(self, value):
        return self.x == value.x and self.y == value.y
    
    def __hash__(self):
        return hash((self.x, self.y))

class Vec2f:
    x: float
    y: float

    def __init__(self, x: float, y: float) -> None:
        self.x = x
        self.y = y
    
    def withinDistance(self, other: object, distance: float) -> bool:
        if isinstance(other, Vec2f):
            return abs(self.x - other.x) < distance and abs(self.y - other.y) < distance
        return False
    
    def __str__(self) -> str:
        return f"Vec2f{{x: {self.x}, y: {self.y}}}"
    
class TilePos(Vec2i):
    ...

class ChunkPos(Vec2i):
    def serialize(self) -> str:
        data = ""
        data += str(self.x)
        data += ","
        data += str(self.y)
        return data

    def deserialize(self, data: str):
        (x_str, y_str) = data.split(",")
        self.x = int(x_str)
        self.y = int(y_str)

def random(origin: int, bound: int) -> int:
    return randint(origin, bound)

def lerp(delta: float, start: float, end: float) -> float:
    maxTime = 2000
    return start + delta * (end-start)

def posToTilePos(pos: Vec2f) -> TilePos:
    return TilePos(int(pos.x / 32), int(pos.y / 32))

def posToChunkPos(pos: Vec2i) -> ChunkPos:
    chunk_x = math.floor(pos.x / CHUNK_SIZE)
    chunk_y = math.floor(pos.y / CHUNK_SIZE)
    return ChunkPos(-int(chunk_x), -int(chunk_y))